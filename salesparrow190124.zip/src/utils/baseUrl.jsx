const getBaseUrl = () => {
  return "https://webservice.salesparrow.in/";
  // return "http://192.168.29.124:5000/";
};
export { getBaseUrl };