const getBaseUrl = () => {
  return "https://webservice.salesparrow.in/";
};
export { getBaseUrl };