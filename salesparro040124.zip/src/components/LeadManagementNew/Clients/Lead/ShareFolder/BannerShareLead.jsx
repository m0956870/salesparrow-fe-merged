import React from 'react'

const BannerShareLead = () => {
  return (
    <div>BannerShareLead</div>
  )
}

export default BannerShareLead