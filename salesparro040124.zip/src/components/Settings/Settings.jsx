import React from 'react'
import group from "../../images/group.png";


const Settings = () => {
  return (
    <div className="container">
    <div className="beat_heading">
      <div className="beat_left" >
        <div className="icon">
          <img src={group} alt="icon" />
        </div>
        <div className="title">Settings</div>
      </div>
  
    </div></div>
  )
}

export default Settings